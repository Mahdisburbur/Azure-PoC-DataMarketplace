# Layer 1: Storage & Security

## وظیفه اصلی
ذخیره‌سازی داده‌های ساختار یافته و غیرساختار یافته + امنیت (رمزنگاری، IAM).

## ابزارهای مورد استفاده
- Azure Blob Storage  
- Azure Key Vault  
- Azure Entra ID (IAM)

## فایل‌های موجود
- `main.tf` → کد Terraform برای ساخت Storage و Key Vault  
- `script.ps1` → اسکریپت PowerShell برای تست اتصال  

## وضعیت PoC
بخشی پیاده‌سازی شده و تست اولیه موفقیت‌آمیز بوده است.


## مراحل اجرا (Step-by-Step)
1. اطمینان حاصل کنید که Terraform و PowerShell نصب هستند.
2. دستور زیر را برای اجرای کد Terraform اجرا کنید:
   ```bash
   terraform init
   terraform apply
   ```
3. سپس برای تست اتصال، اسکریپت PowerShell را اجرا کنید:
   ```powershell
   ./script.ps1 -storageAccountName "dmpocstorageacct" -containerName "testcontainer"
   ```
4. بررسی کنید که فایل `sample.txt` در Blob Storage آپلود شده باشد.
