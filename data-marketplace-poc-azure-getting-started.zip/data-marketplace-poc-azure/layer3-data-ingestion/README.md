# Layer 3: Data Ingestion

## وظیفه اصلی
دریافت داده‌ها از منابع مختلف (Batch/Streaming) و ورود به بازار داده.

## ابزارهای مورد استفاده
- Azure Event Hub  
- Azure Data Factory  
- Azure Databricks

## وضعیت PoC
منابع Event Hub و Data Factory ایجاد و تست اتصال انجام شده است.


## مراحل اجرا (Step-by-Step)
1. دستور زیر را برای ایجاد Event Hub و Data Factory اجرا کنید:
   ```bash
   terraform init
   terraform apply
   ```
2. وارد Azure Portal شوید و بررسی کنید که **Event Hub** و **Data Factory** ایجاد شده‌اند.
3. یک Pipeline ساده در Data Factory بسازید تا داده‌ها وارد Event Hub شوند.
