# Layer 2: Governance, Monitoring & Compliance

در این لایه سیاست‌های داده، کیفیت داده، امنیت و انطباق پیاده‌سازی می‌شوند.  
ابزارهای کلیدی: Microsoft Purview, Azure Sentinel, Entra ID.  

PoC فعلی شامل تعریف سیاست‌های اولیه و Lineage در Purview است.


## مراحل اجرا (Step-by-Step)
1. دستور زیر را برای ایجاد سرویس Purview و Log Analytics اجرا کنید:
   ```bash
   terraform init
   terraform apply
   ```
2. وارد Azure Portal شوید و بررسی کنید که **Purview Account** و **Log Analytics Workspace** ایجاد شده‌اند.
3. در Purview می‌توانید سیاست‌های Lineage و Data Classification تعریف کنید.
