# Data Marketplace PoC on Azure

این مخزن شامل نمونه‌سازی اثبات مفهوم (PoC) برای معماری بازار داده بر بستر Azure است.

---

## 🚀 Getting Started (شروع سریع)

### پیش‌نیازها
- یک اشتراک Azure معتبر
- نصب ابزارها:
  - [Azure CLI] (`az --version`)
  - [Terraform] (نسخه 1.4+)
  - (اختیاری برای لایه 1) **PowerShell 7+** و ماژول‌های Az

### احراز هویت در Azure
```bash
az login
az account set --subscription "<YOUR_SUBSCRIPTION_ID>"
```
> در فایل‌های Terraform، شناسه‌ی **Tenant ID** را با مقدار واقعی خود جایگزین کنید.

### کلون و اجرای نمونه‌ها
```bash
git clone <this-repo-url>
cd data-marketplace-poc-azure
```

#### اجرای لایه 1 (Storage & Security)
```bash
cd layer1-storage-security
terraform init
terraform apply
# (اختیاری) تست آپلود فایل
pwsh ./script.ps1 -storageAccountName "dmpocstorageacct" -containerName "testcontainer"
```

#### اجرای لایه 2 (Governance & Compliance)
```bash
cd ../layer2-governance-compliance
terraform init
terraform apply
```

#### اجرای لایه 3 (Data Ingestion)
```bash
cd ../layer3-data-ingestion
terraform init
terraform apply
```

#### اجرای لایه 4 (Analytics & Dashboard)
```bash
cd ../layer4-analytics-dashboard
terraform init
terraform apply
```

### پاک‌سازی منابع (Clean Up)
برای جلوگیری از هزینه‌ها، در هر پوشه دستور زیر را اجرا کنید:
```bash
terraform destroy
```

---

## ساختار و لایه‌ها

### Layer 1: Storage & Security
- [README](./layer1-storage-security/README.md)  
- ![Diagram](./layer1-storage-security/diagram.png)

### Layer 2: Governance & Compliance
- [README](./layer2-governance-compliance/README.md)  
- ![Diagram](./layer2-governance-compliance/diagram.png)

### Layer 3: Data Ingestion
- [README](./layer3-data-ingestion/README.md)  
- ![Diagram](./layer3-data-ingestion/diagram.png)

### Layer 4: Analytics & Dashboard
- [README](./layer4-analytics-dashboard/README.md)  
- ![Diagram](./layer4-analytics-dashboard/diagram.png)

---

## نکات مهم
- نام‌ها و منطقه‌ها در Terraform نمونه هستند؛ در محیط واقعی، آن‌ها را طبق استاندارد نام‌گذاری سازمان خود تغییر دهید.
- برای محیط‌های تیمی، توصیه می‌شود Backend از نوع **Azure Storage** برای Terraform state پیکربندی شود.
- دسترسی‌های IAM حداقلی را رعایت کنید (Principle of Least Privilege).
